# Nestmate
Dark-premium roommate discovery app starter for web + iOS + Android.

## Stack
Expo + React Native + TypeScript (shared app), Express + TypeScript API, MongoDB/Mongoose, JWT scaffold, Socket.IO scaffold.

## Run
1. Install Node.js 20+ and MongoDB.
2. API: `cd apps/api && cp .env.example .env && npm install && npm run dev`
3. App: `cd apps/mobile && npm install && npx expo start`
4. Press `w` for web, or scan the QR code with Expo Go.
5. For a physical phone, set `EXPO_PUBLIC_API_URL` to your computer's LAN IP, not localhost.

This is an MVP foundation. Demo profiles are fictional. Before production, add email/phone verification, identity-verification provider, moderation/reporting, validation, rate limiting, tests, privacy/consent flows and secure deployment secrets.

